<?php

class conexao
{
    private static $instancia;

    // Impedir instanciação
    private function __construct()
    {
    }
    // Impedir clonar
    private function __clone()
    {
    }

    //Impedir utilização do Unserialize
    private function __wakeup()
    {
    }

    public static function conexao()
    {
        try {
            $root = "root";
            $pass = "";
            self::$instancia = new PDO("mysql:host=localhost;dbname=LTP2;", $root, $pass);
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
        return self::$instancia;
    }
}
