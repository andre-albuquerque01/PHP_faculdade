<?php
include "conexao.php";
include "Contato.php";
include "iDaoModeCrud.PHP";
class crud implements iDaoModeCrud
{
    private $tabela;
    private $pdo;

    public function __construct()
    {
        $this->tabela = "contato";
        $this->pdo = conexao::conexao();
    }

    public function create($object)
    {
        $nome = $object->getNome();
        $email = $object->getEmail();
        $telefone = $object->getTelefone();
        $id = $object->getId();
        $sql = "INSERT INTO {$this->tabela} (NOME, EMAIL, TELEFONE) VALUES (:nome, :email, :telefone)";
        $stm = $this->pdo->prepare($sql);
        $stm->bindValue(":nome", $nome);
        $stm->bindValue(":email", $email);
        $stm->bindValue(":telefone", $telefone);
        $stm->execute();
    }
    public function read($param)
    {
        $sql = "SELECT * FROM {$this->tabela}";
        $stm = $this->pdo->query($sql);
        return $stm->fetchAll();
    }
    public function getId()
    {
        $sql = "SELECT * FROM {$this->tabela}";
        $stm = $this->pdo->query($sql);
        $choic = $stm->fetch();
        $idReturn = $choic['ID'];
        return $idReturn;
    }
    public function update($object)
    {
        $nome = $object->getNome();
        $email = $object->getEmail();
        $telefone = $object->getTelefone();
        $id = $object->getId();
        $sql = "UPDATE {$this->tabela} SET NOME=:nome, EMAIL=:email, TELEFONE=:telefone WHERE {$id}";
        $stm = $this->pdo->prepare($sql);
        $stm->bindValue(":nome", $nome);
        $stm->bindValue(":email", $email);
        $stm->bindValue(":telefone", $telefone);
        $stm->execute();
    }
    public function delete($param)
    {
    }
}
$contato = new Contato("Andre", "albuquerqeu@gamil", "1988585585");
$PersitenciaContato1 = new crud();
$contato->setNome("lucas Silva");
$contato->setEmail("lucas@teste.com.br");
var_dump($PersitenciaContato1->read(1));